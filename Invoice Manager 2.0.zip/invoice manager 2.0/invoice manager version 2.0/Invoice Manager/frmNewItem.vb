﻿Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Public Class frmNewItem

    Public strCompanyName As String
    Public strAddress As String
    Public strInvoiceNumber As String
    Public strDate As String

  

    Private Sub txtUnitPrice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUnitPrice.KeyPress

        On Error Resume Next

        'User can only use backspace and numbers. 
        Select Case e.KeyChar
            Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".", vbBack
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtUnitPrice_LostFocus(sender As Object, e As EventArgs) Handles txtUnitPrice.LostFocus

        On Error Resume Next
        txtLineTotal.Text = "$" & (CDbl(cboQuantity.Text) * CDbl(txtUnitPrice.Text)).ToString

    End Sub

    Private Sub txtDescription_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDescription.KeyPress

        On Error Resume Next

        'User Can only enter numbers and backspace.
        Select Case e.KeyChar
            Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                  "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "-", ",", vbBack, ChrW(Keys.Space)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtDescription_TextChanged(sender As Object, e As EventArgs) Handles txtDescription.TextChanged

        On Error Resume Next

        ' Automatically Proper Case the string while the user is typing
        Dim strSel_start As Integer
        Dim strSel_length As Integer

        strSel_start = txtDescription.SelectionStart
        strSel_length = txtDescription.SelectionLength
        txtDescription.Text = StrConv(txtDescription.Text, VbStrConv.ProperCase)
        txtDescription.SelectionStart = strSel_start
        txtDescription.SelectionLength = strSel_length
    End Sub

    Private Sub frmNewItem_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        On Error Resume Next

        'Closing application
        btnExitNew_Click(sender, e)
    End Sub

    Private Sub frmNewItem_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Clearing all fields. 
        cboQuantity.SelectedIndex = 0
        txtUnitPrice.Clear()
        txtLineTotal.Clear()
        txtDescription.Clear()


        'Fixing Rezing issue by setting formBoarderStyle to sizable, AutoScaleMode to DPI and adding statement below to load time form.
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        On Error Resume Next

        'establishing connection with sql server
        EstablishConnection()

        '  Dim objConnection As New SqlConnection(SqlConnectionString)
        ' Dim objSQLCommand As New SqlCommand

        If cboQuantity.Text = "" Then
            MsgBox("Please Enter Quantity!")
            cboQuantity.Focus()
            Exit Sub
        End If

        If txtDescription.Text = "" Then
            MsgBox("Please Enter Item Description!")
            txtDescription.Focus()
            Exit Sub
        End If

        If txtUnitPrice.Text = "" Then
            MsgBox("Please Enter Item Item UnitPrice!")
            txtUnitPrice.Focus()
            Exit Sub
        End If

        If txtLineTotal.Text = "" Then
            MsgBox("Please make sure Line Total has a Total!")
            txtLineTotal.Focus()
            Exit Sub
        End If

        If strInvoiceNumber = Nothing Then
            strInvoiceNumber = 0
        End If


        ' Access database connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        'Opening access database
        AccessConnection.Open()

        '' create the queque
        sql = " INSERT INTO Tab_Invoice (Quantity, Decription_Of_Item, Unit_Price, Line_Total, date_due, company_name, invoice_number, address_to ) VALUES " & _
             " ('" & Trim(cboQuantity.Text) & "','" & Trim(txtDescription.Text) & "','" & Trim(txtUnitPrice.Text) & "','" & Trim(txtLineTotal.Text) & "','" & strDate & "','" & strCompanyName & "','" & strInvoiceNumber & "','" & strAddress & "')"

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)


        If strInvoiceNumber = 0 Then
            'Used to obtain ISAN of just added Record. To be the invoice Number
            sql = "SELECT @@IDENTITY"

            AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
            AccessDataAdapter.Fill(AccessDataSet)

            strInvoiceNumber = AccessDataSet.Tables(0).Rows(0)(0).ToString()
            frmNewInvoice.txtInvoice.Text = strInvoiceNumber

            sql = " UPDATE Tab_Invoice Set invoice_number = '" & strInvoiceNumber & "'" & _
                  " Where ISAN = " & strInvoiceNumber

            AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
            AccessDataAdapter.Fill(AccessDataSet)

            frmNewInvoice.intInvoiceFromAdd = strInvoiceNumber

        End If

       

        'Closing access Database.
        AccessConnection.Close()

        ' Clean Access Connection. 
        AccessConnection = Nothing
        AccessDataAdapter = Nothing
        AccessDataSet = Nothing

        'Clearing all fields. 
        cboQuantity.SelectedIndex = 0
        txtUnitPrice.Clear()
        txtLineTotal.Clear()
        txtDescription.Clear()

        'After adding new Item Close Add Screen. 
        Me.Close()

    End Sub

    Private Sub btnExitNew_Click(sender As Object, e As EventArgs) Handles btnExitNew.Click

        On Error Resume Next
        'Clearing all fields. 
        cboQuantity.SelectedIndex = 0
     
        'Closing Application
        Me.Hide()
    End Sub

End Class