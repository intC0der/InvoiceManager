﻿Public Class frmInvoiceView

    Public strInvoiceNumber As String

    Private Sub frmInvoiceView_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        On Error Resume Next

        'TODO: This line of code loads data into the 'MainDataSet.Tab_Invoice' table. You can move, or remove it, as needed.
        'Me.Tab_InvoiceTableAdapter.Fill(Me.MainDataSet.Tab_Invoice)
        Me.Tab_InvoiceTableAdapter.FillBy(Me.MainDataSet.Tab_Invoice, strInvoiceNumber)
        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub SavedInvoicesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SavedInvoicesToolStripMenuItem.Click

        On Error Resume Next

        'Open email invoices form. 
        frmEmaiInvoices.ShowDialog()
    End Sub
End Class