﻿Public Class mainFrm

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs)

        On Error Resume Next

        'Closing Application
        Me.Close()
    End Sub

    Private Sub NewInvoiceToolStripMenuItem_Click(sender As Object, e As EventArgs)

        On Error Resume Next

        'Opening new application
        frmNewInvoice.ShowDialog()
    End Sub


    Private Sub EditInvoiceToolStripMenuItem_Click(sender As Object, e As EventArgs)

        On Error Resume Next

        'Edit Invoice form
        frmEditInvoice.ShowDialog()
    End Sub

    Private Sub SavedInvoicesToolStripMenuItem_Click(sender As Object, e As EventArgs)

        On Error Resume Next

        'Opening send email form. 
        frmEmaiInvoices.ShowDialog()
    End Sub

    
    Private Sub mainFrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        On Error Resume Next

        'Fixing Rezing issue by setting formBoarderStyle to sizable, AutoScaleMode to DPI and adding statement below to load time form.
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D

        'Loading information at start up. 
        Button2_Click(sender, e)

        'Disabling Button. 
        Button5.Enabled = False
        btnPrint.Enabled = False

    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        On Error Resume Next

        'Opening send email form. 
        frmEmaiInvoices.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        On Error Resume Next

        'Closing Application
        Me.Close()
    End Sub

    Private Sub MenuToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        On Error Resume Next

        'Sending intSAN information to Edit Form. 
        frmEditInvoice.invoiceNumber = CInt(frmViewAll.ListView1.FocusedItem.SubItems(0).Text)

        'Edit Invoice form
        frmEditInvoice.ShowDialog()


        'Everytime there is a new add refresh listview 
        frmViewAll.Load_listview1()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' On Error Resume Next

        'Opening new application
        frmNewInvoice.ShowDialog()

        'Everytime there is a new add refresh listview 
        frmViewAll.Load_listview1()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        ' frmViewAll.Close()
        frmViewAll.TopLevel = False
        Me.panel2.Controls.Add(frmViewAll)
        frmViewAll.Show()

        frmViewAll.Load_listview1()
        frmViewAll.ListView1.Enabled = True
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click

        On Error Resume Next

        frmInvoiceView.strInvoiceNumber = CStr(frmViewAll.ListView1.FocusedItem.SubItems(0).Text)
        frmInvoiceView.ShowDialog()
    End Sub

End Class