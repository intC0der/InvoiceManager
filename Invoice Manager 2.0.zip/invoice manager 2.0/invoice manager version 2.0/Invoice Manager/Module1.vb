﻿Module Module1


    'Connection String For production environment. 
    Public AccessConnectionString As String
    Public AccessConnectionString1 As String
    Public AccessConnectionString2 As String

    'Variable to check if user is connected to the internet. 
    Public blnIsConnected As Boolean
    Public blnIsUpdated As Boolean

    Public Sub EstablishConnection()

        '  MsgBox(Application.StartupPath)

        'Access Connection string. 
        AccessConnectionString = "PROVIDER = Microsoft.jet.OLEDB.4.0;Data Source =  " & Application.StartupPath & "\Invoice_database.MDB;Jet OLEDB:Database Password=5789231;"

    End Sub

    Public Sub EstablishConnection1()
        AccessConnectionString1 = "PROVIDER = Microsoft.jet.OLEDB.4.0;Data Source =  " & Application.StartupPath & "\Invoice_database.MDB;Jet OLEDB:Database Password=5789231;"

    End Sub

    Public Sub EstablishConnection2()
        AccessConnectionString2 = "PROVIDER = Microsoft.jet.OLEDB.4.0;Data Source =  " & Application.StartupPath & "\Invoice_database.MDB;Jet OLEDB:Database Password=5789231;"
    End Sub

End Module
