﻿Imports System.Data.SqlClient
Imports System.Text.RegularExpressions



Public Class frmNewInvoice

    Public intInvoiceFromAdd As Integer

    Private Sub frmNewInvoice_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        On Error Resume Next

        'Closing application
        btnExitNew_Click(sender, e)
    End Sub

    Private Sub frmNewInvoice_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        On Error Resume Next

        lblDateDue.Text = ""
        txtCompany.Enabled = True
        txtCompany.Clear()
        txtInvoice.Clear()
        txtAddressto.Clear()
        ListView1.Items.Clear()
        txtAddressto.Enabled = False
        lblDateDue.Enabled = False
        txtInvoice.Enabled = False
        txtCompany.Enabled = True
        txtLineTotal.Clear()


        'Disabling buttons at start up. 
        txtAddressto.Enabled = False
        lblDateDue.Enabled = False
        txtInvoice.Enabled = False
        btnChangeNew.Enabled = False
        btnAdd.Enabled = False
        btnDeleteNew.Enabled = False
        btnPrintNew.Enabled = False


        'Fixing Rezing issue by setting formBoarderStyle to sizable, AutoScaleMode to DPI and adding statement below to load time form.
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D

    End Sub

    Private Sub txtCompany_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCompany.KeyPress

        On Error Resume Next

        'User Can only enter numbers and backspace.
        Select Case e.KeyChar
            Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                  "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", vbBack, ChrW(Keys.Space)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtCompany_LostFocus(sender As Object, e As EventArgs) Handles txtCompany.LostFocus

        On Error Resume Next

        'Enabling Address and seeting focus
        txtAddressto.Enabled = True
        txtAddressto.Focus()

    End Sub

    Private Sub txtAddressto_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAddressto.KeyPress

        On Error Resume Next

        'User Can only enter numbers and backspace.
        Select Case e.KeyChar
            Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                  "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "-", ",", vbBack, ChrW(Keys.Space)
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtAddressto_LostFocus(sender As Object, e As EventArgs) Handles txtAddressto.LostFocus

        On Error Resume Next

        'Enabling Date and setting focus
        lblDateDue.Enabled = True
        lblDateDue.Focus()

    End Sub

    'Private Sub txtDate_KeyPress(sender As Object, e As KeyPressEventArgs)

    '    On Error Resume Next

    '    'User Can only enter numbers and backspace.
    '    Select Case e.KeyChar
    '        Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "/", vbBack
    '            e.Handled = False
    '        Case Else
    '            e.Handled = True
    '    End Select
    'End Sub

    Private Sub txtDate_LostFocus(sender As Object, e As EventArgs)

        On Error Resume Next

        'Enabling Txt Invoice and setting focus
        txtInvoice.Focus()

    End Sub

    Private Sub txtInvoice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtInvoice.KeyPress

        On Error Resume Next

        'User Can only enter numbers and backspace.
        Select Case e.KeyChar
            Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", vbBack
                e.Handled = False
            Case Else
                e.Handled = True
        End Select

    End Sub


    Public Sub Load_listview1()

        '**********************************************************************************************
        ' Load Counties to listview1 
        '**********************************************************************************************

        On Error Resume Next

        ' Number of columns in the listview
        Dim strItemcoll(5) As String

        'Clear the listview
        ListView1.Items.Clear()
        ListView1.GridLines = True
        ListView1.Refresh()

        'Total of Line Items
        Dim lngTotalLineItems As Double = 0

        ' Format the date and time format
        Dim strDTFormat As String = "MM/dd/yyyy"

        ' Access database connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        'Opening access database
        AccessConnection.Open()

        '' create the queque
        sql = " Select ISAN, quantity, Decription_Of_Item, Unit_Price, Line_Total From Tab_Invoice " & _
              " WHERE invoice_number = " & intInvoiceFromAdd

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet, "Invoice Manager")

       
        'Closing access Database.
        AccessConnection.Close()

        Dim Inti As Integer = 0

        'Now adding the Items in Listview
        For Inti = 0 To AccessDataSet.Tables(0).Rows.Count - 1

            strItemcoll(0) = AccessDataSet.Tables(0).Rows(Inti)(1).ToString()
            strItemcoll(1) = AccessDataSet.Tables(0).Rows(Inti)(2).ToString()
            strItemcoll(2) = AccessDataSet.Tables(0).Rows(Inti)(3).ToString()
            strItemcoll(3) = AccessDataSet.Tables(0).Rows(Inti)(4).ToString()

            Dim lvi As New ListViewItem(strItemcoll)
            lvi.Tag = AccessDataSet.Tables(0).Rows(Inti)(0).ToString
            ListView1.Items.Add(lvi)

            lngTotalLineItems = lngTotalLineItems + CDbl(strItemcoll(3))

        Next

        'Assinging total Line Value and Color
        txtLineTotal.ForeColor = Color.Red
        txtLineTotal.Text = ("$" & lngTotalLineItems.ToString)

        'Closing access Database.
        AccessConnection.Close()

        ' Clean Access Connection. 
        AccessConnection = Nothing
        AccessDataAdapter = Nothing
        AccessDataSet = Nothing

        '**********************************************************************************************
        ' End - Load the listview1 
        '**********************************************************************************************

    End Sub

    Private Sub ListView1_Click(sender As Object, e As EventArgs) Handles ListView1.Click

        On Error Resume Next

        btnDeleteNew.Enabled = True
        btnChangeNew.Enabled = True
    End Sub

    Private Sub ListView1_DoubleClick(sender As Object, e As EventArgs) Handles ListView1.DoubleClick

        On Error Resume Next

        'Same action as clicking the change button. 
        btnChangeNew_Click(sender, e)
    End Sub


    Private Sub txtAddressto_TextChanged(sender As Object, e As EventArgs) Handles txtAddressto.TextChanged

        On Error Resume Next

        ' Automatically Proper Case the string while the user is typing
        Dim strSel_start As Integer
        Dim strSel_length As Integer

        strSel_start = txtAddressto.SelectionStart
        strSel_length = txtAddressto.SelectionLength
        txtAddressto.Text = StrConv(txtAddressto.Text, VbStrConv.ProperCase)
        txtAddressto.SelectionStart = strSel_start
        txtAddressto.SelectionLength = strSel_length
    End Sub

    Private Sub txtCompany_TextChanged(sender As Object, e As EventArgs) Handles txtCompany.TextChanged

        On Error Resume Next

        ' Automatically Proper all UPPERCase the string while the user is typing
        txtCompany.Text = txtCompany.Text.ToUpper
        txtCompany.Select(txtCompany.Text.Length, 0)
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' On Error Resume Next

        If txtAddressto.Text = "" Then
            MsgBox("Please Enter Address to!!")
            txtAddressto.Focus()
            Exit Sub
        End If

        If txtCompany.Text = "" Then
            MsgBox("Please Enter Company Name!!")
            txtCompany.Focus()
            Exit Sub
        End If

        If Not IsDate(lblDateDue.Text) Then
            MsgBox("Please Enter date Format: mm/dd/yyyy")
            lblDateDue_Click(sender, e)
            Exit Sub
        End If

        'Sending TXT box values to new form. 
        frmNewItem.strAddress = txtAddressto.Text
        frmNewItem.strCompanyName = txtCompany.Text
        frmNewItem.strDate = lblDateDue.Text
        frmNewItem.strInvoiceNumber = txtInvoice.Text

        'Opening add Form
        frmNewItem.ShowDialog()

        'Load ListView after item is added. 
        Load_listview1()

        'Enabling Print
        btnPrintNew.Enabled = True
    End Sub

    Private Sub btnChangeNew_Click(sender As Object, e As EventArgs) Handles btnChangeNew.Click

        On Error Resume Next

        If txtAddressto.Text = "" Then
            MsgBox("Please Enter Address to!!")
            txtAddressto.Focus()
            Exit Sub
        End If

        If txtCompany.Text = "" Then
            MsgBox("Please Enter Company Name!!")
            txtCompany.Focus()
            Exit Sub
        End If

        If Not IsDate(lblDateDue.Text) Then
            MsgBox("Please Enter date Format: mm/dd/yyyy")
            lblDateDue_Click(sender, e)
            Exit Sub
        End If

        If txtInvoice.Text = "" Then
            MsgBox("Please Ivoice Number!!")
            txtInvoice.Focus()
            Exit Sub
        End If

        'Sending TXT box values to new form. 
        frmChangeItem.strAddress = txtAddressto.Text
        frmChangeItem.strCompanyName = txtCompany.Text
        frmChangeItem.strDate = lblDateDue.Text
        frmChangeItem.strInvoiceNumber = txtInvoice.Text

        'sending ISAN to Change form
        frmChangeItem.intISAN = ListView1.FocusedItem.Tag

        'Opening Change form
        frmChangeItem.ShowDialog()

        'Reload County_lisview after Changind item.
        Load_listview1()

        'Disabling Change and Delete after a record is changed. 
        btnDeleteNew.Enabled = False
        btnChangeNew.Enabled = False
    End Sub

  
    Private Sub btnDeleteNew_Click(sender As Object, e As EventArgs) Handles btnDeleteNew.Click
        '**********************************************************************************************
        ' Delete Item
        '**********************************************************************************************

        On Error Resume Next

        ' Access database connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        'Choosing seletected item
        Dim intISAN As Integer
        Dim strDescription As String


        ' assign county variables
        intISAN = ListView1.FocusedItem.Tag
        strDescription = ListView1.SelectedItems(0).SubItems(1).Text

        If MessageBox.Show("Are you sure want to Delete " & strDescription & "?", "Delete Item From Invoice", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then

            'Opening access database
            AccessConnection.Open()

            ' Select from Access Database
            sql = "DELETE FROM Tab_Invoice Where ISAN = " & intISAN

            AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
            AccessDataAdapter.Fill(AccessDataSet, "Permit Tracker")

            'Closing access Database.
            AccessConnection.Close()

            ' Clean Access Connection. 
            AccessConnection = Nothing
            AccessDataAdapter = Nothing
            AccessDataSet = Nothing

            'Confirmation of Delete
            MsgBox(strDescription & " Deleted!", MessageBoxButtons.OK, "Delete Item From Invoice")

            'Reload County_lisview after deleting. 
            Load_listview1()

        End If

        '**********************************************************************************************
        'END-  Delete Item
        '**********************************************************************************************
    End Sub

    Private Sub btnPrintNew_Click(sender As Object, e As EventArgs) Handles btnPrintNew.Click

        On Error Resume Next

        'Sending invoice Number to Invoice Viewer
        frmInvoiceView.strInvoiceNumber = txtInvoice.Text

        'Opening Invoice
        frmInvoiceView.ShowDialog()
    End Sub

    Private Sub btnExitNew_Click(sender As Object, e As EventArgs) Handles btnExitNew.Click

        On Error Resume Next

        'Clearing and enabling buttions. 
        lblDateDue.Text = ""
        btnChangeNew.Enabled = False
        btnDeleteNew.Enabled = False
        btnPrintNew.Enabled = False

        'closing application
        Me.Hide()
    End Sub


    Private Sub lblDateDue_Click(sender As Object, e As EventArgs) Handles lblDateDue.Click

        '******************************************************************************************
        '* Show the Calendar
        '******************************************************************************************
        If IsDate(lblDateDue.Text) Then
            ' Pass the date to the Calendar if there is one
            frmCalendar.PassedInDate = CDate(lblDateDue.Text)
        End If
        'Call calendar form
        frmCalendar.ShowDialog()

        If IsDate(frmCalendar.PassedOutDate) Then
            lblDateDue.Text = Format(CDate(frmCalendar.PassedOutDate.ToString()), "MM/dd/yyyy")
        Else
            lblDateDue.Text = ""
        End If

        '************************************************************************************************
        '* End Show the Calendar
        '*************************************************************************************************
    End Sub

    Private Sub btnChangeHeader_Click(sender As Object, e As EventArgs) Handles btnChangeHeader.Click
        lblDateDue_Click(sender, e)
    End Sub

    Private Sub lblDateDue_TextChanged(sender As Object, e As EventArgs) Handles lblDateDue.TextChanged

        'Enabling Buttons
        btnAdd.Enabled = True
    End Sub
End Class


