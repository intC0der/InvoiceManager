﻿Public Class frmViewAll

    Sub Load_listview1()

        '**********************************************************************************************
        ' Load Counties to listview1 
        '**********************************************************************************************
        'On Error Resume Next

        EstablishConnection()

        ' Number of columns in the listview
        Dim strItemcoll(8) As String

        'Clear the listview
        ListView1.Items.Clear()
        ListView1.GridLines = True
        ListView1.Refresh()

        'Total of Line Items
        Dim lngTotalLineItems As Double = 0

        ' Format the date and time format
        Dim strDTFormat As String = "MM/dd/yyyy"

        ' Access database connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        'Opening access database
        AccessConnection.Open()

        '' create the queque
        sql = " Select DISTINCT invoice_number, address_to, company_name FROM  Tab_Invoice " ' & _

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)


        If AccessDataSet.Tables(0).Rows.Count = 0 Then
            '  MsgBox("Invoice Not Found")
            ListView1.Items.Add("No Invoices Found")
            ListView1.Enabled = False
            Exit Sub

        End If

        Dim Inti As Integer = 0

        'Now adding the Items in Listview
        For Inti = 0 To AccessDataSet.Tables(0).Rows.Count - 1

            strItemcoll(0) = AccessDataSet.Tables(0).Rows(Inti)(0).ToString()
            strItemcoll(1) = AccessDataSet.Tables(0).Rows(Inti)(1).ToString()
            strItemcoll(2) = AccessDataSet.Tables(0).Rows(Inti)(2).ToString()
            strItemcoll(3) = Date_of_Record(AccessDataSet.Tables(0).Rows(Inti)(0).ToString())

            Dim lvi As New ListViewItem(strItemcoll)
            lvi.Tag = AccessDataSet.Tables(0).Rows(Inti)(0).ToString
            ListView1.Items.Add(lvi)


        Next

        'Closing access Database.
        AccessConnection.Close()

        ' Clean Access Connection. 
        AccessConnection = Nothing
        AccessDataAdapter = Nothing
        AccessDataSet = Nothing

        '**********************************************************************************************
        ' End - Load the listview1 
        '**********************************************************************************************

    End Sub

    Private Sub frmViewAll_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Loading Listview with all invoices. 
        Load_listview1()
    End Sub

    Private Sub ListView1_Click(sender As Object, e As EventArgs) Handles ListView1.Click

        'Enabling Edit button once invoice clicked. 
        mainFrm.Button5.Enabled = True
    End Sub

    Private Sub ListView1_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles ListView1.MouseDoubleClick

        On Error Resume Next

        'Sending intSAN information to Edit Form. 
        frmEditInvoice.invoiceNumber = CInt(ListView1.FocusedItem.Tag.ToString)

        'Opening Edit Screeen. 
        mainFrm.Button5.PerformClick()
    End Sub

   
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

        'Enabling Print Button on main screen. 
        mainFrm.btnPrint.Enabled = True
    End Sub



    Function Date_of_Record(strInvoiceNumber As String) As String

        'On Error Resume Next

        EstablishConnection()

        ' Format the date and time format
        Dim strDTFormat As String = "MM/dd/yyyy"

        ' Access database connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        'Opening access database
        AccessConnection.Open()

        '' create the queque
        sql = " Select date_entered FROM  Tab_Invoice " & _
              " Where Invoice_Number = " & strInvoiceNumber

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)


        If AccessDataSet.Tables(0).Rows.Count > 0 Then

            Return Format(CDate(AccessDataSet.Tables(0).Rows(0)(0).ToString()), strDTFormat)

            'Closing access Database.
            AccessConnection.Close()

            ' Clean Access Connection. 
            AccessConnection = Nothing
            AccessDataAdapter = Nothing
            AccessDataSet = Nothing

            Exit Function

        End If



        'Closing access Database.
        AccessConnection.Close()

        ' Clean Access Connection. 
        AccessConnection = Nothing
        AccessDataAdapter = Nothing
        AccessDataSet = Nothing

        Return "No Date"
    End Function

End Class