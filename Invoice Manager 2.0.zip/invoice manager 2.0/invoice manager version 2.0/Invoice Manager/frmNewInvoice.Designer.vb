﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewInvoice
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmNewInvoice))
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Quantity = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Description = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.UnitPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.LineTotal = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtAddressto = New System.Windows.Forms.TextBox()
        Me.txtCompany = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtInvoice = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtLineTotal = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnDeleteNew = New System.Windows.Forms.Button()
        Me.btnPrintNew = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnChangeNew = New System.Windows.Forms.Button()
        Me.btnExitNew = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblDateDue = New System.Windows.Forms.Label()
        Me.btnChangeHeader = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.Quantity, Me.Description, Me.UnitPrice, Me.LineTotal})
        Me.ListView1.FullRowSelect = True
        Me.ListView1.GridLines = True
        Me.ListView1.Location = New System.Drawing.Point(7, 257)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(810, 364)
        Me.ListView1.TabIndex = 0
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'Quantity
        '
        Me.Quantity.Text = "Quantity"
        Me.Quantity.Width = 150
        '
        'Description
        '
        Me.Description.Text = "Description"
        Me.Description.Width = 450
        '
        'UnitPrice
        '
        Me.UnitPrice.Text = "UnitPrice"
        Me.UnitPrice.Width = 100
        '
        'LineTotal
        '
        Me.LineTotal.Text = "Line Total"
        Me.LineTotal.Width = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 127)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Address To:"
        '
        'txtAddressto
        '
        Me.txtAddressto.Location = New System.Drawing.Point(103, 127)
        Me.txtAddressto.MaxLength = 75
        Me.txtAddressto.Name = "txtAddressto"
        Me.txtAddressto.Size = New System.Drawing.Size(556, 20)
        Me.txtAddressto.TabIndex = 1
        '
        'txtCompany
        '
        Me.txtCompany.Location = New System.Drawing.Point(103, 85)
        Me.txtCompany.MaxLength = 50
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.Size = New System.Drawing.Size(556, 20)
        Me.txtCompany.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Company Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 169)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Date Due:"
        '
        'txtInvoice
        '
        Me.txtInvoice.Location = New System.Drawing.Point(103, 214)
        Me.txtInvoice.Name = "txtInvoice"
        Me.txtInvoice.Size = New System.Drawing.Size(141, 20)
        Me.txtInvoice.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 214)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Invoice #:"
        '
        'txtLineTotal
        '
        Me.txtLineTotal.Enabled = False
        Me.txtLineTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLineTotal.Location = New System.Drawing.Point(706, 627)
        Me.txtLineTotal.Name = "txtLineTotal"
        Me.txtLineTotal.Size = New System.Drawing.Size(111, 22)
        Me.txtLineTotal.TabIndex = 9
        Me.txtLineTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(660, 630)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Total:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.Controls.Add(Me.btnDeleteNew)
        Me.Panel1.Controls.Add(Me.btnPrintNew)
        Me.Panel1.Controls.Add(Me.btnAdd)
        Me.Panel1.Controls.Add(Me.btnChangeNew)
        Me.Panel1.Controls.Add(Me.btnExitNew)
        Me.Panel1.Location = New System.Drawing.Point(7, 667)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(811, 59)
        Me.Panel1.TabIndex = 35
        '
        'btnDeleteNew
        '
        Me.btnDeleteNew.BackColor = System.Drawing.Color.White
        Me.btnDeleteNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDeleteNew.ForeColor = System.Drawing.Color.Transparent
        Me.btnDeleteNew.Image = CType(resources.GetObject("btnDeleteNew.Image"), System.Drawing.Image)
        Me.btnDeleteNew.Location = New System.Drawing.Point(344, 2)
        Me.btnDeleteNew.Name = "btnDeleteNew"
        Me.btnDeleteNew.Size = New System.Drawing.Size(57, 53)
        Me.btnDeleteNew.TabIndex = 34
        Me.btnDeleteNew.UseVisualStyleBackColor = False
        '
        'btnPrintNew
        '
        Me.btnPrintNew.BackColor = System.Drawing.Color.White
        Me.btnPrintNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPrintNew.ForeColor = System.Drawing.Color.Transparent
        Me.btnPrintNew.Image = CType(resources.GetObject("btnPrintNew.Image"), System.Drawing.Image)
        Me.btnPrintNew.Location = New System.Drawing.Point(555, 1)
        Me.btnPrintNew.Name = "btnPrintNew"
        Me.btnPrintNew.Size = New System.Drawing.Size(57, 53)
        Me.btnPrintNew.TabIndex = 11
        Me.btnPrintNew.UseVisualStyleBackColor = False
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.Color.White
        Me.btnAdd.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdd.ForeColor = System.Drawing.Color.Transparent
        Me.btnAdd.Image = CType(resources.GetObject("btnAdd.Image"), System.Drawing.Image)
        Me.btnAdd.Location = New System.Drawing.Point(9, 3)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(52, 51)
        Me.btnAdd.TabIndex = 33
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'btnChangeNew
        '
        Me.btnChangeNew.BackColor = System.Drawing.Color.White
        Me.btnChangeNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnChangeNew.ForeColor = System.Drawing.Color.Transparent
        Me.btnChangeNew.Image = CType(resources.GetObject("btnChangeNew.Image"), System.Drawing.Image)
        Me.btnChangeNew.Location = New System.Drawing.Point(170, 3)
        Me.btnChangeNew.Name = "btnChangeNew"
        Me.btnChangeNew.Size = New System.Drawing.Size(57, 53)
        Me.btnChangeNew.TabIndex = 10
        Me.btnChangeNew.UseVisualStyleBackColor = False
        '
        'btnExitNew
        '
        Me.btnExitNew.BackColor = System.Drawing.Color.White
        Me.btnExitNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExitNew.ForeColor = System.Drawing.Color.Transparent
        Me.btnExitNew.Image = CType(resources.GetObject("btnExitNew.Image"), System.Drawing.Image)
        Me.btnExitNew.Location = New System.Drawing.Point(713, 3)
        Me.btnExitNew.Name = "btnExitNew"
        Me.btnExitNew.Size = New System.Drawing.Size(57, 53)
        Me.btnExitNew.TabIndex = 7
        Me.btnExitNew.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(70, 36)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(125, 24)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "New Invoice"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(16, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 36
        Me.PictureBox1.TabStop = False
        '
        'lblDateDue
        '
        Me.lblDateDue.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblDateDue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDateDue.Location = New System.Drawing.Point(103, 169)
        Me.lblDateDue.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDateDue.Name = "lblDateDue"
        Me.lblDateDue.Size = New System.Drawing.Size(143, 21)
        Me.lblDateDue.TabIndex = 38
        '
        'btnChangeHeader
        '
        Me.btnChangeHeader.BackColor = System.Drawing.Color.White
        Me.btnChangeHeader.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.btnChangeHeader.FlatAppearance.BorderSize = 3
        Me.btnChangeHeader.ForeColor = System.Drawing.Color.Transparent
        Me.btnChangeHeader.Image = CType(resources.GetObject("btnChangeHeader.Image"), System.Drawing.Image)
        Me.btnChangeHeader.Location = New System.Drawing.Point(251, 157)
        Me.btnChangeHeader.Name = "btnChangeHeader"
        Me.btnChangeHeader.Size = New System.Drawing.Size(36, 37)
        Me.btnChangeHeader.TabIndex = 39
        Me.btnChangeHeader.UseVisualStyleBackColor = False
        '
        'frmNewInvoice
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(830, 738)
        Me.Controls.Add(Me.btnChangeHeader)
        Me.Controls.Add(Me.lblDateDue)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtLineTotal)
        Me.Controls.Add(Me.txtInvoice)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtCompany)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtAddressto)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ListView1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmNewInvoice"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "New Invoice"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Quantity As System.Windows.Forms.ColumnHeader
    Friend WithEvents Description As System.Windows.Forms.ColumnHeader
    Friend WithEvents UnitPrice As System.Windows.Forms.ColumnHeader
    Friend WithEvents LineTotal As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtAddressto As System.Windows.Forms.TextBox
    Friend WithEvents txtCompany As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtInvoice As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtLineTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnDeleteNew As System.Windows.Forms.Button
    Friend WithEvents btnPrintNew As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnChangeNew As System.Windows.Forms.Button
    Friend WithEvents btnExitNew As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblDateDue As System.Windows.Forms.Label
    Friend WithEvents btnChangeHeader As System.Windows.Forms.Button
End Class
