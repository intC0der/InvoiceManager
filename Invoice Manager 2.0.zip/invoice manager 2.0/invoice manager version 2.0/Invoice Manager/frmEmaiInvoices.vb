﻿Imports System.Net.Mail

Public Class frmEmaiInvoices

    Public strFileString As String


    Private Sub frmEmaiInvoices_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Enabling confirmation picture
        PictureBox2.Visible = False

        'Fixing Rezing issue by setting formBoarderStyle to sizable, AutoScaleMode to DPI and adding statement below to load time form.
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
    End Sub

    Private Sub btnExitNew_Click(sender As Object, e As EventArgs) Handles btnExitNew.Click

        On Error Resume Next

        'Clearing text fields. 
        txtEmailTo.Clear()
        txtSubject.Clear()
        txtFile.Enabled = True
        txtFile.Clear()
        txtFile.Enabled = False
        txtMessage.Clear()

        'closing email application
        Me.Hide()
    End Sub

    Private Sub btnSendMail_Click(sender As Object, e As EventArgs) Handles btnSendMail.Click

        On Error Resume Next

        If txtFile.Text = "" Then
            MsgBox("Please Choose File!")
            btnDownloadFile.Focus()
            Exit Sub
        End If

        If txtEmailTo.Text = "" Then
            MsgBox("Please Enter Email to")
            txtEmailTo.Focus()
            Exit Sub
        End If

        If txtSubject.Text = "" Then
            MsgBox("Please Enter Subject!")
            txtSubject.Focus()
            Exit Sub
        End If

        If txtMessage.Text = "" Then
            MsgBox("Please Enter Message!")
            txtMessage.Focus()
            Exit Sub
        End If

        Dim mail As New MailMessage()
        Dim SmtpServer As New SmtpClient("smtp.gmail.com")
        mail.From = New MailAddress("invoicemanagerdotnet@gmail.com")
        mail.[To].Add(txtEmailTo.Text)
        mail.Subject = txtSubject.Text
        mail.Body = txtMessage.Text

        Dim attachment As System.Net.Mail.Attachment
        attachment = New System.Net.Mail.Attachment(strFileString)
        mail.Attachments.Add(attachment)

        SmtpServer.Port = 587
        SmtpServer.Credentials = New System.Net.NetworkCredential("invoicemanagerdotnet@gmail.com", "invoicemanager123456789")
        SmtpServer.EnableSsl = True

        SmtpServer.Send(mail)
        MessageBox.Show("Invoice Sent!")
    End Sub

    Private Sub btnDownloadFile_Click(sender As Object, e As EventArgs) Handles btnDownloadFile.Click

        On Error Resume Next

        'Picking first file to be compared
        OpenFileDialog1.ShowDialog()
        strFileString = OpenFileDialog1.FileName
        txtFile.Text = strFileString

        If OpenFileDialog1.FileName <> "" Then
            'Enabling Confirmation 
            PictureBox2.Visible = True
            btnNotApproved.Visible = False
        End If

       
    End Sub

    Private Sub txtSubject_TextChanged(sender As Object, e As EventArgs) Handles txtSubject.TextChanged

    End Sub
End Class