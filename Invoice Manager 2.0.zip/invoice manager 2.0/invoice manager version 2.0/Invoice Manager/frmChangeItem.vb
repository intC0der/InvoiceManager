﻿Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Public Class frmChangeItem

    Public intISAN As Integer

    Public strCompanyName As String
    Public strAddress As String
    Public strInvoiceNumber As String
    Public strDate As String

    Private Sub frmChangeItem_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        On Error Resume Next

        'Closing application
        btnExitNew_Click(sender, e)
    End Sub

    Private Sub frmChangeItem_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '**********************************************************************************************
        ' Load the County Record to textbox
        '**********************************************************************************************

        On Error Resume Next

        'Change cboquantity type to 
        cboQuantity.DropDownStyle = ComboBoxStyle.Simple

        ' Format the date and time format
        Dim strDTFormat As String = "MM/dd/yyyy"

        ' Access database connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        'Opening access database
        AccessConnection.Open()

        ' create the queque
        sql = " Select Quantity, Decription_Of_Item, Unit_Price, Line_Total From Tab_Invoice  " & _
              " Where ISAN = " & intISAN

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet)


        'Closing access Database.
        AccessConnection.Close()


        Dim Inti As Integer = 0

        'Now adding the Items in Listview
        For Inti = 0 To AccessDataSet.Tables(0).Rows.Count - 1

            cboQuantity.Text = AccessDataSet.Tables(0).Rows(Inti)(0).ToString()
            txtDescription.Text = AccessDataSet.Tables(0).Rows(Inti)(1).ToString()
            txtUnitPrice.Text = AccessDataSet.Tables(0).Rows(Inti)(2).ToString()

        Next

        txtLineTotal.Text = "$" & (CDbl(cboQuantity.Text) * CDbl(txtUnitPrice.Text)).ToString

        ' Clean Access Connection. 
        AccessConnection = Nothing
        AccessDataAdapter = Nothing
        AccessDataSet = Nothing


        'Focus to text box
        cboQuantity.Select()

        'Fixing Rezing issue by setting formBoarderStyle to sizable, AutoScaleMode to DPI and adding statement below to load time form.
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D

        '**********************************************************************************************
        ' End - Load the County Record  to textbox
        '**********************************************************************************************
    End Sub

  

    Private Sub btnChangeItem_Click(sender As Object, e As EventArgs)



    End Sub

    Private Sub cboQuantity_LostFocus(sender As Object, e As EventArgs) Handles cboQuantity.LostFocus

        On Error Resume Next

        txtLineTotal.Text = "$" & (CDbl(cboQuantity.Text) * CDbl(txtUnitPrice.Text)).ToString
    End Sub

    Private Sub txtUnitPrice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUnitPrice.KeyPress

        On Error Resume Next

        'User can only use backspace and numbers. 
        Select Case e.KeyChar
            Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".", vbBack
                e.Handled = False
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub txtUnitPrice_LostFocus(sender As Object, e As EventArgs) Handles txtUnitPrice.LostFocus

        On Error Resume Next

        txtLineTotal.Text = "$" & (CDbl(cboQuantity.Text) * CDbl(txtUnitPrice.Text)).ToString
    End Sub

   
    Private Sub txtDescription_TextChanged(sender As Object, e As EventArgs) Handles txtDescription.TextChanged

        On Error Resume Next

        ' Automatically Proper Case the string while the user is typing
        Dim strSel_start As Integer
        Dim strSel_length As Integer

        strSel_start = txtDescription.SelectionStart
        strSel_length = txtDescription.SelectionLength
        txtDescription.Text = StrConv(txtDescription.Text, VbStrConv.ProperCase)
        txtDescription.SelectionStart = strSel_start
        txtDescription.SelectionLength = strSel_length
    End Sub

    Private Sub txtUnitPrice_TextChanged(sender As Object, e As EventArgs) Handles txtUnitPrice.TextChanged

    End Sub

    Private Sub btnExitNew_Click(sender As Object, e As EventArgs) Handles btnExitNew.Click

        On Error Resume Next

        'Closing Application
        Me.Hide()
    End Sub

   
    Private Sub btnChangeNew_Click(sender As Object, e As EventArgs) Handles btnChangeNew.Click
        On Error Resume Next

        'establishing connection with sql server
        EstablishConnection()

        ' Dim objConnection As New SqlConnection(SqlConnectionString)
        ' Dim objSQLCommand As New SqlCommand
        '
        If cboQuantity.Text = "" Then
            MsgBox("Please Enter Quantity!")
            cboQuantity.Focus()
            Exit Sub
        End If

        If txtDescription.Text = "" Then
            MsgBox("Please Enter Item Description!")
            txtDescription.Focus()
            Exit Sub
        End If

        If txtUnitPrice.Text = "" Then
            MsgBox("Please Enter Item Item UnitPrice!")
            txtUnitPrice.Focus()
            Exit Sub
        End If

        If txtLineTotal.Text = "" Then
            MsgBox("Please make sure Line Total has a Total!")
            txtLineTotal.Focus()
            Exit Sub
        End If


        ' Access database connection
        Dim AccessDataSet As New DataSet
        Dim AccessDataAdapter As OleDb.OleDbDataAdapter
        Dim sql As String
        Dim AccessConnection As New OleDb.OleDbConnection
        AccessConnection.ConnectionString = AccessConnectionString

        'Opening access database
        AccessConnection.Open()

        ' Select from Access Database
        sql = " UPDATE Tab_Invoice Set Quantity = '" & Trim(cboQuantity.Text) & "'," & _
              " Decription_Of_Item = '" & Trim(txtDescription.Text) & "'," & _
              " Unit_Price =  '" & Trim(txtUnitPrice.Text) & "'," & _
              " Line_Total =  '" & Trim(txtLineTotal.Text) & "'," & _
              " date_due =  '" & strDate & "'," & _
              " company_name =  '" & strCompanyName & "'," & _
              " invoice_number =  '" & strInvoiceNumber & "'," & _
              " address_to =  '" & strAddress & "'" & _
              " Where ISAN = " & intISAN

        AccessDataAdapter = New OleDb.OleDbDataAdapter(sql, AccessConnection)
        AccessDataAdapter.Fill(AccessDataSet, "Permit Tracker")


        'Closing access Database.
        AccessConnection.Close()

        ' Clean Access Connection. 
        AccessConnection = Nothing
        AccessDataAdapter = Nothing
        AccessDataSet = Nothing

        'Clearing all fields. 
        cboQuantity.SelectedIndex = 0
        txtUnitPrice.Clear()
        txtLineTotal.Clear()
        txtDescription.Clear()

        'After adding new Item Close Add Screen. 
        btnExitNew_Click(sender, e)
    End Sub
End Class